# Copyright Notice

Copyright © Mojang Studios  
**WARNING:** Some files in this project may contain copyrighted materials from Mojang Studios. Minecraft and related assets are the property of Mojang Studios. This project is **not affiliated** with, endorsed, or sponsored by Mojang Studios. All trademarks, copyrights, and other intellectual property rights are the property of their respective owners.

**No part of these files may be reproduced, distributed, or transmitted in any form without permission from [mckuhei](mailto:mckuhei@mcmodule.org).**

# DMCA Takedown / Deletion Requests

For any DMCA takedown or content deletion requests, please contact: [mckuhei@mcmodule.org](mailto:mckuhei@mcmodule.org)



# 版权声明

版权所有 © Mojang Studios  
**警告：** 本项目中的某些文件可能包含来自 Mojang Studios 的受版权保护的材料。Minecraft 及相关资产为 Mojang Studios 所有。此项目与 Mojang Studios **无关**，且未获得 Mojang Studios 的认可或赞助。所有商标、版权和其他知识产权均为其各自所有者的财产。

**未经 [mckuhei](mailto:mckuhei@mcmodule.org) 许可，不得以任何形式复制、分发或传播这些文件的任何部分。**

# DMCA 删除请求

如有任何 DMCA 删除请求，请联系：[mckuhei@mcmodule.org](mailto:mckuhei@mcmodule.org)