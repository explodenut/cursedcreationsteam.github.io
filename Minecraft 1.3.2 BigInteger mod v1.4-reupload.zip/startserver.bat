@Echo off

:: 检查 Java 是否存在
java.exe -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    Echo Java not found. Quitting...
    exit /b
)

:: 检查 Minecraft 客户端文件
set "MC_JAR=minecraft_1.3.2.jar"
set "MC_NO_SIG_JAR=minecraft_1.3.2_no_sig.jar"
set "MC_APPDATA=%APPDATA%\.minecraft\versions\1.3.2\1.3.2.jar"

if not exist %MC_NO_SIG_JAR% (
    if not exist %MC_JAR% (
        if not exist %MC_APPDATA% (
            Echo Minecraft 1.3.2 not found. Please start Minecraft 1.3.2 in the launcher or copy the client as 'minecraft_1.3.2.jar'.
            exit /b
        )
        :: 复制 Minecraft 客户端
        copy /B %MC_APPDATA% %MC_JAR%
    )
    :: 移除签名
    java.exe -cp . SignaturesRemover %MC_JAR% %MC_NO_SIG_JAR%
)

:: 启动 Minecraft 服务器
java.exe %* -cp minecraft.zip;%MC_NO_SIG_JAR%;minecraft.zip net.minecraft.server.MinecraftServer
exit /b
