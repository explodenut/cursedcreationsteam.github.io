#!/bin/bash

if ! java -version >/dev/null 2>&1; then
  echo "Java not found. Quitting..."
  exit 1
fi

if [ -f "minecraft_1.3.2_no_sig.jar" ]; then
  :
elif [ -f "minecraft_1.3.2.jar" ]; then
  java -cp . SignaturesRemover minecraft_1.3.2.jar minecraft_1.3.2_no_sig.jar
elif [ -f "$HOME/.minecraft/versions/1.3.2/1.3.2.jar" ]; then
  cp "$HOME/.minecraft/versions/1.3.2/1.3.2.jar" minecraft_1.3.2.jar
  java -cp . SignaturesRemover minecraft_1.3.2.jar minecraft_1.3.2_no_sig.jar
else
  echo "Minecraft 1.3.2 not found. Please start Minecraft 1.3.2 in the launcher or copy the 1.3.2 client as 'minecraft_1.3.2.jar'"
  exit 1
fi

java "$@" -cp minecraft.zip:minecraft_1.3.2_no_sig.jar:minecraft.zip net.minecraft.server.MinecraftServer
