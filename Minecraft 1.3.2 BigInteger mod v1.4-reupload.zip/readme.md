# Minecraft 1.3.2 BigInteger edition

Not completed yet, This version only for test. May have some bugs. Please don't share, Thank you!

You can report bugs by contact [mckuhei@mcmodule.org](mailto:mckuhei@mcmodule.org).

Sources code is available here: http://git.mcmodule.org/mckuhei/1.3.2_128bit.

## How to start server?

1. Make sure you already patched minecraft client.

2. Rename to `minecraft_server.jar`.

3. Open your console.

4. Run `java -cp minecraft_server.jar net.minecraft.server.MinecraftServer`.

   Or just click startserver.bat

## How to fix stripelands?

Add `-Dnet.minecraft.client.FIX_RENDERER=true` to jvm arguments.

## How to fix chunk invisible?

Make sure you disable `Advanced OpenGL`, If doesn't work, Add `-Dnet.minecraft.src.DISABLE_FRUSTRUM=true -Dnet.minecraft.src.DISABLE_OCCLUSION_CHECK=true` to jvm arguments.

## How to enable "original" 64bit farlands?

Add `-Dnet.minecraft.src.NoiseGeneratorOctaves.noiseType=longType -Dnet.minecraft.src.Constants.DISABLE_MODULO=true` to jvm arguments.

## History

### 1.0-prelease

First release

### 1.0

Add BigInteger statistics.

Fix "Internal server error".

Fix block collision.

Fix stripelands.

### 1.1

Add server debug pie, use `/debug start` to enable.

Add a option to disable occlusion check.

Fix fp loss cause teleport offset.

Use BigDecimal to store player position.

Add fp precision display.

## 1.2

Fix frustrum and OpenGL occlusion check.

Fix biome generation.

Restore world decoration.

Add 64bit perlin noise.

## 1.3

Fix high fp loss cause game froze.

Fix player movement and entity path finding.

Fix tree generation.

Fix rail.

Fix all block renderer.

Add fringelands.

Add new perlin generator.

## 1.4

Add a option `-Dnet.minecraft.src.Constants.DISABLE_ENTITY_UPDATE=true` to disable entity update.

Add a simple way to start minecraft server.